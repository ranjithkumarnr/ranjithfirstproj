﻿using System;
using System.Collections.Generic;

namespace Task.Models
{
    public partial class Meat
    {
        public int Mid { get; set; }
        public int? Pid { get; set; }
        public string? Mname { get; set; }
    }
}
