﻿using System;
using System.Collections.Generic;

namespace Task.Models
{
    public partial class Paste
    {
        public int Aid { get; set; }
        public int? Pid { get; set; }
        public string? Aname { get; set; }
    }
}
