﻿using System;
using System.Collections.Generic;

namespace Task.Models
{
    public partial class Chocolate
    {
        public int Cid { get; set; }
        public int? Pid { get; set; }
        public string? Cname { get; set; }
    }
}
