﻿using System;
using System.Collections.Generic;

namespace Task.Models
{
    public partial class Rice
    {
        public int Rid { get; set; }
        public int? Pid { get; set; }
        public string? Rname { get; set; }
    }
}
