﻿using System;
using System.Collections.Generic;

namespace Task.Models
{
    public partial class Saltysnack
    {
        public int Ssid { get; set; }
        public int? Pid { get; set; }
        public string? Ssname { get; set; }
    }
}
