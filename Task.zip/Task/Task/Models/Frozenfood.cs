﻿using System;
using System.Collections.Generic;

namespace Task.Models
{
    public partial class Frozenfood
    {
        public int Fid { get; set; }
        public int? Pid { get; set; }
        public string? Fname { get; set; }
    }
}
