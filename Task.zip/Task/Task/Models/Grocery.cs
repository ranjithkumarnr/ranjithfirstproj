﻿using System;
using System.Collections.Generic;

namespace Task.Models
{
    public partial class Grocery
    {
        public int Pid { get; set; }
        public string? Pname { get; set; }
    }
}
