﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Task.Models
{
    public partial class taskContext : DbContext
    {
        public taskContext()
        {
        }

        public taskContext(DbContextOptions<taskContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Chocolate> Chocolates { get; set; } = null!;
        public virtual DbSet<Frozenfood> Frozenfoods { get; set; } = null!;
        public virtual DbSet<Grocery> Groceries { get; set; } = null!;
        public virtual DbSet<Meat> Meats { get; set; } = null!;
        public virtual DbSet<Paste> Pastes { get; set; } = null!;
        public virtual DbSet<Rice> Rice { get; set; } = null!;
        public virtual DbSet<Saltysnack> Saltysnacks { get; set; } = null!;
        public virtual DbSet<Soap> Soaps { get; set; } = null!;
        public virtual DbSet<Sodum> Soda { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=task;Integrated Security=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Chocolate>(entity =>
            {
                entity.HasKey(e => e.Cid)
                    .HasName("PK__chocolat__D837D05FFB5D98D5");

                entity.ToTable("chocolates");

                entity.Property(e => e.Cid)
                    .ValueGeneratedNever()
                    .HasColumnName("cid");

                entity.Property(e => e.Cname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("cname");

                entity.Property(e => e.Pid).HasColumnName("pid");
            });

            modelBuilder.Entity<Frozenfood>(entity =>
            {
                entity.HasKey(e => e.Fid)
                    .HasName("PK__frozenfo__D9908D64F72CB2DB");

                entity.ToTable("frozenfood");

                entity.Property(e => e.Fid)
                    .ValueGeneratedNever()
                    .HasColumnName("fid");

                entity.Property(e => e.Fname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("fname");

                entity.Property(e => e.Pid).HasColumnName("pid");
            });

            modelBuilder.Entity<Grocery>(entity =>
            {
                entity.HasKey(e => e.Pid)
                    .HasName("PK__grocery__DD37D91A9E1AF4C4");

                entity.ToTable("grocery");

                entity.Property(e => e.Pid)
                    .ValueGeneratedNever()
                    .HasColumnName("pid");

                entity.Property(e => e.Pname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("pname");
            });

            modelBuilder.Entity<Meat>(entity =>
            {
                entity.HasKey(e => e.Mid)
                    .HasName("PK__meat__DF5032ECDA6E406A");

                entity.ToTable("meat");

                entity.Property(e => e.Mid)
                    .ValueGeneratedNever()
                    .HasColumnName("mid");

                entity.Property(e => e.Mname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("mname");

                entity.Property(e => e.Pid).HasColumnName("pid");
            });

            modelBuilder.Entity<Paste>(entity =>
            {
                entity.HasKey(e => e.Aid)
                    .HasName("PK__paste__DE508E2E31F346D4");

                entity.ToTable("paste");

                entity.Property(e => e.Aid)
                    .ValueGeneratedNever()
                    .HasColumnName("aid");

                entity.Property(e => e.Aname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("aname");

                entity.Property(e => e.Pid).HasColumnName("pid");
            });

            modelBuilder.Entity<Rice>(entity =>
            {
                entity.HasKey(e => e.Rid)
                    .HasName("PK__rice__C2B7EDE83EC3C198");

                entity.ToTable("rice");

                entity.Property(e => e.Rid)
                    .ValueGeneratedNever()
                    .HasColumnName("rid");

                entity.Property(e => e.Pid).HasColumnName("pid");

                entity.Property(e => e.Rname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("rname");
            });

            modelBuilder.Entity<Saltysnack>(entity =>
            {
                entity.HasKey(e => e.Ssid)
                    .HasName("PK__saltysna__366F2DDC812E71B1");

                entity.ToTable("saltysnacks");

                entity.Property(e => e.Ssid)
                    .ValueGeneratedNever()
                    .HasColumnName("ssid");

                entity.Property(e => e.Pid).HasColumnName("pid");

                entity.Property(e => e.Ssname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("ssname");
            });

            modelBuilder.Entity<Soap>(entity =>
            {
                entity.HasKey(e => e.Sid)
                    .HasName("PK__soap__DDDFDD361F08F96E");

                entity.ToTable("soap");

                entity.Property(e => e.Sid)
                    .ValueGeneratedNever()
                    .HasColumnName("sid");

                entity.Property(e => e.Pid).HasColumnName("pid");

                entity.Property(e => e.Sname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("sname");
            });

            modelBuilder.Entity<Sodum>(entity =>
            {
                entity.HasKey(e => e.Oid)
                    .HasName("PK__soda__C2FFCF137BD4E812");

                entity.ToTable("soda");

                entity.Property(e => e.Oid)
                    .ValueGeneratedNever()
                    .HasColumnName("oid");

                entity.Property(e => e.Oname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("oname");

                entity.Property(e => e.Pid).HasColumnName("pid");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
