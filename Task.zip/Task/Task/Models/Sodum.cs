﻿using System;
using System.Collections.Generic;

namespace Task.Models
{
    public partial class Sodum
    {
        public int Oid { get; set; }
        public int? Pid { get; set; }
        public string? Oname { get; set; }
    }
}
