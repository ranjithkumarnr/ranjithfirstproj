﻿using System;
using System.Collections.Generic;

namespace Task.Models
{
    public partial class Soap
    {
        public int Sid { get; set; }
        public int? Pid { get; set; }
        public string? Sname { get; set; }
    }
}
